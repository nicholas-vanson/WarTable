import {places,types,available} from './rules.js';
const ns='http://www.w3.org/2000/svg';
function node(tag,attrs,text=''){
  const el=document.createElementNS(ns,tag);
  for(const [k,v] of Object.entries(attrs))el.setAttribute(k,v);
  el.textContent=text;return el;
}
const project=(lon,lat)=>[(lon+13)*34,(69-lat)*52];
// Hand-spaced seats in the projected territory interiors. Arrival seats fan out from
// the actual approach to the defenders, with a separate pair for each legal origin.
const formations={
  hb:{center:[610,926],home:{inf:[602,952],tank:[616,899]}},
  wg:{center:[716,932],home:{inf:[703,957],tank:[729,900]}},
  nb:{center:[421,1100],home:{inf:[387,1094],tank:[427,1150]},
    hb:{inf:[454,1042],tank:[443,1097]}},
  fr:{center:[571,1087],home:{inf:[536,1103],tank:[594,1133]},
    hb:{inf:[549,1021],tank:[609,1038]},wg:{inf:[670,1053],tank:[656,1105]}}
};
const position=id=>formations[id].center;
// Bézier handles are surveyed in map coordinates. The two Normandy approaches share
// a narrow coastal passage, then diverge around the arriving infantry and armor.
const approaches={
  'hb-fr':{inf:[[607,982],[575,990]],tank:[[648,935],[640,996]]},
  'wg-fr':{inf:[[719,987],[719,1025]],tank:[[756,977],[712,1098]]},
  'hb-nb':{
    inf:[[580,926],[553,944],[526,971], [506,991],[482,1000]],
    tank:[[590,922],[543,943],[517,969], [473,1024],[407,1028]]
  }
};
// Each of the eight home counters gets four saved random bits. Keep the small jitter
// within the tested interior margin. Inbound seats stay open for every approach.
function homeOffsets(seed){
  const offsets={};
  for(const id of Object.keys(formations)){
    offsets[id]={};
    for(const type of types){
      offsets[id][type]=[(seed&3)*8/3-4,((seed>>>2)&3)*8/3-4];
      seed>>>=4;
    }
  }
  return offsets;
}
function seat(id,group,type,spread,offsets){
  const center=position(id);
  const shift=group==='home'?offsets[id][type]:[0,0];
  return formations[id][group][type].map((v,i)=>center[i]+spread*(v+shift[i]-center[i]));
}
function movementArc(from,to,type,spread,tokenScale,offsets){
  const start=seat(from,'home',type,spread,offsets),end=seat(to,from,type,spread,offsets);
  const handles=approaches[from+'-'+to][type];
  function atCounterEdge(point,handle){
    const dx=handle[0]-point[0],dy=handle[1]-point[1];
    const t=Math.min(.9,1/Math.max(Math.abs(dx)/(22*tokenScale),Math.abs(dy)/(14*tokenScale)));
    return [point[0]+dx*t,point[1]+dy*t];
  }
  const tail=atCounterEdge(start,handles[0]),tip=atCounterEdge(end,handles.at(-1));
  return 'M'+tail.join(' ')+' C'+[...handles,tip].map(p=>p.join(' ')).join(' ');
}

// Battles pool casualties by type. Apportion the surviving counters to their committed
// approaches for display, preserving the exact total without assigning a new game rule.
function arrivals(game,to){
  const orders=game.orders.filter(o=>o.to===to);
  if(game.phase==='plan')return orders;
  const battle=game.battles.find(b=>b.to===to&&!b.resolved);
  if(!battle)return [];
  const groups=orders.map(o=>({from:o.from,units:{}}));
  for(const type of types){
    const total=orders.reduce((n,o)=>n+o.units[type],0);
    if(!total)continue;
    const shares=orders.map((o,i)=>{
      const share=battle.attack[type]*o.units[type]/total;
      groups[i].units[type]=Math.floor(share);
      return {i,remainder:share-Math.floor(share)};
    });
    const assigned=groups.reduce((n,g)=>n+g.units[type],0);
    shares.sort((a,b)=>b.remainder-a.remainder);
    for(const {i} of shares.slice(0,battle.attack[type]-assigned))groups[i].units[type]++;
  }
  return groups;
}
const pencilLine='M-24 -5 C-21 -14 -4 -17 10 -16 C23 -15 30 -8 27 2 C25 12 9 16 -5 15 C-19 15 -29 10 -28 2 C-28 -5 -23 -11 -15 -14';
const selectionOrange='#a4441b';
function pencilMark(){
  const g=node('g',{'aria-hidden':'true','pointer-events':'none',fill:'none',
    stroke:selectionOrange,'stroke-linecap':'round',filter:'url(#pencil-grain)',mask:'url(#pencil-reveal)'});
  g.append(node('path',{d:pencilLine,'stroke-width':1.6,opacity:.84,'stroke-dasharray':'6 .35 2 .3 9 .55'}),
    node('path',{d:pencilLine,transform:'translate(.45 .5) scale(1.025 .96)','stroke-width':.75,opacity:.66,'stroke-dasharray':'2 .55 .6 .5 5 .9'}),
    node('path',{d:pencilLine,transform:'translate(-.5 .2) scale(1.04 1.04)','stroke-width':.65,opacity:.52,'stroke-dasharray':'.2 1.1 .5 1.7'}));
  return g;
}
// The Situation Map front is a shallow pencil arc with short strokes facing the attackers.
// Draw it in local coordinates so an existing annotation can follow the counters without replaying.
function drawFront(from,to){
  const group=node('g',{'data-from':from,'data-to':to,'clip-path':'url(#inside-'+to+')'});
  const ink=node('g',{fill:'none',stroke:'#ae3835','stroke-linecap':'round','stroke-linejoin':'round',
    filter:'url(#pencil-grain)'});
  const spine='M-30 -2 Q-28 -1 -25 -.4 Q-20 .4 -15 1 Q-10 2 -5 1.6 Q0 1 5 1.4 Q11 2 15 1.1 Q21 .5 25 -.6 Q28 -1.1 30 -2.3';
  const animate=!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const stroke=(d,width,delay,duration,attrs={})=>{
    const line=node('path',{d,'stroke-width':width,pathLength:1,'stroke-dasharray':'1 1',...attrs});
    ink.append(line);
    if(animate)
      line.animate([{strokeDashoffset:1},{strokeDashoffset:0}],{duration,delay,fill:'backwards'});
  };
  stroke(spine,2.1,0,540);
  stroke(spine,.7,40,545,{transform:'translate(.25 .8)',opacity:.66});
  const ticks=[[-25,-.4,-1.5,5.3],[-15,1,-1,6.1],[-5,1.6,-.6,5.1],
    [5,1.4,.3,6.4],[15,1.1,.8,5.5],[25,-.6,1.4,5]];
  for(const [x,y,lean,height] of ticks){
    stroke('M'+x+' '+y+' q'+(lean*.25)+' 2.4 '+lean+' '+height,1.55,(x+30)*9,115);
  }
  group.append(ink);
  return group;
}
// Centerlines follow the open corridors between the hand-spaced formations. Infantry
// and armor occupy successive stretches of each line, as they do in the arrival seats.
const frontLines={
  'hb-nb':[[394,1049],[418,1071]],
  'hb-fr':[[524,1062],[602,1075]],
  'wg-fr':[[629,1058],[618,1111]]
};
function frontTransform(to,group,spread,tokenScale){
  const [start,end]=frontLines[group.from+'-'+to],center=position(to);
  const dx=end[0]-start[0],dy=end[1]-start[1],length=Math.hypot(dx,dy);
  const first=group.units.inf?0:.48,last=group.units.tank?1:.52;
  const mid=(first+last)/2;
  const x=center[0]+spread*(start[0]+mid*dx-center[0]);
  const y=center[1]+spread*(start[1]+mid*dy-center[1]);
  const attacker=formations[to][group.from][group.units.inf?'inf':'tank'];
  const side=Math.sign(dy*(attacker[0]-start[0])-dx*(attacker[1]-start[1]));
  const along=spread*(last-first)/60,across=side*tokenScale/length;
  return 'matrix('+[dx*along,dy*along,dy*across,-dx*across,x,y].join(' ')+')';
}
function drawStack(parent,id,type,number,nation,role,at,tokenScale,detailed,selected,origin){
  const [x,y]=at;
  const unitInk=nation==='Germany'?'#334334':'#294c60';
  const ink=selected?'#fff9df':unitInk;
  const paper=selected?selectionOrange:(nation==='Germany'?'#e6dfbd':'#d8e6e5');
  const name=type==='inf'?'Infantry':'Armor';
  const label=places[id].name+' · '+nation+' · '+name+' × '+number+(origin?' from '+places[origin].name:'');
  const stack=node('g',{'data-place':id,'data-unit':type,'data-count':number,'data-role':role,
    'aria-label':label,cursor:'pointer',transform:'translate('+x+' '+y+') scale('+tokenScale+')'});
  if(origin)stack.dataset.origin=origin;
  stack.append(node('title',{},label),node('rect',{x:-22,y:-22,width:44,height:44,fill:'transparent'}));
  stack.append(node('rect',{x:-19,y:-11,width:38,height:22,rx:1,fill:paper,stroke:selected?'#753515':unitInk,'stroke-width':1.6}));
  stack.append(node('rect',{x:-15,y:-6,width:16,height:12,fill:'none',stroke:ink,'stroke-width':1.3}));
  stack.append(type==='inf'
    ? node('path',{d:'M-15 -6L1 6M-15 6L1 -6',stroke:ink,'stroke-width':1.5})
    : node('ellipse',{cx:-7,cy:0,rx:6.6,ry:3.8,fill:'none',stroke:ink,'stroke-width':1.6}));
  stack.append(node('text',{x:10,y:4,'text-anchor':'middle','font-family':'sans-serif','font-size':13,'font-weight':700,fill:ink},number));
  if(detailed)stack.append(node('text',{x:0,y:24,'text-anchor':'middle','font-family':'sans-serif','font-size':11,'font-weight':650,fill:unitInk,
    stroke:'#f5efd8','paint-order':'stroke','stroke-width':3},(nation==='Germany'?'DE':'FR')+' · '+name));
  parent.append(stack);
}
const labels=[
  ['NORTH SEA',1,55.2,'water'],['BALTIC SEA',19.7,57.3,'water'],['ATLANTIC OCEAN',-8,47.5,'water'],['MEDITERRANEAN SEA',7.3,38,'water'],['BLACK SEA',33.3,43.4,'water'],['NORWEGIAN SEA',.5,66,'water'],
  ['English Channel',-2.4,50.15,'water'],['Bay of Biscay',-4.3,45.3,'water'],['Adriatic Sea',15,43,'water'],
  ['Lille',3.06,50.63,'city'],['Brussels',4.35,50.85,'city'],['Lyon',4.84,45.76,'city'],['Köln',6.96,50.94,'city'],['Vienna',16.37,48.21,'city'],['London',-.12,51.51,'city'],['Paris',2.35,48.86,'city'],['Bordeaux',-.58,44.84,'city'],['Berlin',13.41,52.52,'city'],['Copenhagen',12.57,55.68,'city'],['Rome',12.5,41.9,'city'],['Warsaw',21.01,52.23,'city'],['Moscow',37.62,55.75,'city'],['Madrid',-3.7,40.42,'city'],['Stockholm',18.06,59.33,'city'],['Amsterdam',4.9,52.36,'city'],['Brest',-4.49,48.39,'city']
];
// Curved baselines in the atlas projection. Each span fits the interior of its region.
const landNames=[
  ['Holland Belgium', 'M558 925 Q603 929 643 910', 78],
  ['Western Germany', 'M662 958 Q718 951 763 918', 97],
  ['Normandy Bordeaux', 'M419 1144 Q443 1111 447 1071', 70],
  ['France', 'M535 1073 Q584 1089 635 1080', 90],
  ['UNITED KINGDOM', 'M356 881 Q394 838 406 783', 99],
  ['SCOTLAND', 'M263 660 Q304 643 331 609', 76],
  ['EIRE', 'M148 837 Q173 833 192 817', 44],
  ['NORWAY', 'M738 399 Q780 362 799 308', 99],
  ['SWEDEN', 'M933 444 Q971 402 985 347', 99],
  ['FINLAND', 'M1303 275 Q1348 254 1376 214', 86],
  ['DENMARK', 'M747 671 Q767 648 773 619', 52],
  ['GERMANY', 'M825 884 Q870 896 916 884', 82],
  ['POLAND', 'M1046 915 Q1098 918 1144 894', 90],
  ['BALTIC STATES', 'M1236 692 Q1279 658 1300 608', 95],
  ['WESTERN UKRAINE', 'M1258 1062 Q1326 1051 1381 1007', 122],
  ['BELARUS', 'M1364 764 Q1411 777 1458 764', 86],
  ['SOVIET UNION', 'M1651 688 Q1739 692 1817 653', 153],
  ['ROMANIA', 'M1237 1207 Q1283 1213 1326 1195', 81],
  ['YUGOSLAVIA', 'M1050 1271 Q1089 1307 1140 1319', 92],
  ['NORTHERN ITALY', 'M728 1223 Q782 1252 843 1252', 106],
  ['SOUTHERN ITALY', 'M941 1438 Q957 1484 994 1517', 86],
  ['GREECE', 'M1188 1500 Q1195 1532 1216 1557', 58],
  ['SPAIN', 'M271 1499 Q325 1506 375 1486', 94],
  ['PORTUGAL', 'M163 1571 Q180 1536 177 1497', 68],
  ['SWITZERLAND', 'M678 1168 Q720 1170 757 1151', 72],
  ['SOUTHERN FRANCE', 'M499 1314 Q558 1314 610 1286', 103],
  ['GREATER SOUTHERN GERMANY', 'M824 1129 Q897 1135 964 1104', 128],
];
function buildLandLabels(map,layer){
  const defs=map.querySelector('defs');
  return landNames.map(([name,curve,span],index)=>{
    const id='land-name-'+index;
    defs.append(node('path',{id,d:curve}));
    const size=Math.min(14,span/(name.length*.68));
    const length=Math.min(span,size*name.length*.77);
    const text=node('text',{'font-family':'Georgia,serif','font-size':size,'text-anchor':'middle',
      'fill':'#494c3e','paint-order':'stroke',stroke:'#e7e2ce','stroke-width':1.6,'stroke-linejoin':'round'});
    text.append(node('textPath',{href:'#'+id,startOffset:'50%',textLength:length,lengthAdjust:'spacing'},name));
    layer.append(text);
    return {text,size};
  });
}
const ownerStyle={
  Germany:{ink:'#4d5845',hatch:'german-hatch',angle:37},
  France:{ink:'#345f8a',hatch:'french-hatch',angle:-37}
};
function buildControlBands(map,shapes,regions){
  const defs=map.querySelector('defs'), layer=map.querySelector('#controlBands');
  for(const {ink,hatch,angle} of Object.values(ownerStyle)){
    const pattern=node('pattern',{id:hatch,patternUnits:'userSpaceOnUse',width:4.2,height:4.2,patternTransform:'rotate('+angle+')'});
    pattern.append(node('path',{d:'M2 0V4.2',stroke:ink,'stroke-width':.8}));
    defs.append(pattern);
  }
  const bands={};
  for(const [id,d] of Object.entries(shapes)){
    const href='#territory-'+id;
    defs.append(node('path',{id:href.slice(1),d}));
    const clip=node('clipPath',{id:'inside-'+id});
    clip.append(node('use',{href}));defs.append(clip);
    const band=node('g',{'clip-path':'url(#inside-'+id+')',fill:'none','stroke-linejoin':'round'});
    band.append(node('use',{href,stroke:'currentColor','stroke-width':'var(--outer)',opacity:.15}),
      node('use',{href,stroke:'currentColor','stroke-width':'var(--inner)',opacity:.29}),
      node('use',{href,'stroke-width':'var(--outer)',opacity:.60}));
    layer.append(band);
    const region=node('path',{d,fill:'transparent','data-place':id});
    region.append(node('title',{}));regions.append(region);
    bands[id]={band,region};
  }
  return bands;
}
function buildSeaZones(map,chart){
  const layer=map.querySelector('#seaZones'), numbers=node('g',{'pointer-events':'none'});
  const zones=new Map();
  for(const {number,label,d,neighbors,room,ruleRoom} of chart.zones){
    const area=node('path',{d,'fill-rule':'evenodd',fill:'transparent','data-sea':number,
      'aria-label':'Sea zone '+number});
    area.append(node('title',{},'Sea zone '+number));layer.append(area);
    const [x,y]=label;
    const mark=node('g',{transform:'translate('+x+' '+y+')'});
    // Short horizontal rules distinguish a zone number from a depth contour.
    mark.append(node('path',{d:'M-19 0h4m30 0h4',stroke:'#344f59','stroke-width':1.1}),
      node('text',{y:4.3,'text-anchor':'middle','font-family':'Arial, sans-serif','font-size':13.5,
        'font-weight':700,'letter-spacing':.65,fill:'#314e59',stroke:'#c5d5cd','stroke-width':2.2,
        'paint-order':'stroke'},number));
    numbers.append(mark);
    zones.set(String(number),{area,mark,x,y,neighbors,room,ruleRoom});
  }
  layer.append(node('path',{d:chart.dividers,fill:'none',stroke:'#365664','stroke-width':1.3,
    'stroke-dasharray':'6 3','vector-effect':'non-scaling-stroke',opacity:.73,'pointer-events':'none'}),numbers);
  return zones;
}
const bound=(v,min,max)=>Math.min(max,Math.max(min,v));
export async function atlas(onPick,onView,initial) {
  const map=document.querySelector('#map'), forces=document.querySelector('#forces'), regions=document.querySelector('#regions'),routes=document.querySelector('#routes');
  const shapes=await (await fetch('./assets/territories.json')).json();
  const chart=await (await fetch('./assets/sea-zones.json')).json();
  const bands=buildControlBands(map,shapes,regions), zones=buildSeaZones(map,chart);
  const control=map.querySelector('#controlBands'), intel=document.querySelector('#mapIntel');
  let inspectedPlace=null, inspectedSea=null, lastScale=0;
  function inspectSea(id){
    if(inspectedSea)zones.get(inspectedSea).area.setAttribute('fill','transparent');
    inspectedSea=id;
    if(id)zones.get(id).area.setAttribute('fill','#426d8133');
  }
  const labelGroup=document.querySelector('#labels');
  for(const [name,lon,lat,kind] of labels){
    const [x,y]=project(lon,lat);
    if(kind==='city')labelGroup.append(node('circle',{cx:x,cy:y,r:2.4,fill:'#42463a'}));
    labelGroup.append(node('text',{x:kind==='city'?x+5:x,y:kind==='city'?y-4:y,'text-anchor':kind==='city'?'start':'middle',
      fill:kind==='water'?'#506b6c':'#535747','font-family':kind==='city'?'Arial, sans-serif':'Georgia,serif','font-weight':kind==='city'?600:400,'font-size':kind==='city'?7.2:kind==='water'?15:13,'letter-spacing':kind==='city'?0:kind==='water'?2:1.8,'font-style':kind==='water'?'italic':'normal',
      'paint-order':'stroke','stroke-width':1.8,stroke:kind==='water'?'#bacbcc':'#dcd9c1'},name));
  }
  const detailPlate=map.querySelector('#detailPlate');
  const landLabels=buildLandLabels(map,labelGroup);
  const selection=map.querySelector('#selection'),reveal=map.querySelector('#pencil-stroke');
  reveal.setAttribute('d',pencilLine);
  const fronts=map.querySelector('#fronts'), frontMarks=new Map();
  let selectionKey='',layoutSeed,offsets;
  function showSelection(key,at,tokenScale){
    if(key!==selectionKey){
      selection.replaceChildren();
      reveal.getAnimations().forEach(animation=>animation.cancel());
      if(key){
        selection.append(pencilMark());
        if(!window.matchMedia('(prefers-reduced-motion: reduce)').matches)
          reveal.animate([{strokeDashoffset:1},{strokeDashoffset:0}],{duration:480,easing:'ease-out'});
      }
      selectionKey=key;
    }
    if(key)selection.setAttribute('transform','translate('+at.join(' ')+') scale('+tokenScale+')');
  }
  let game=null,focus=null,target=null,selectedType=null;
  let view=initial&&[initial.x,initial.y,initial.z].every(Number.isFinite)?{...initial}:{x:590,y:985,z:1};
  const pointers=new Map();let gesture=null;
  function metrics(){
    const w=map.clientWidth||1,h=map.clientHeight||1;
    const base=Math.min(w/650,h/480);
    const scale=Math.max(Math.min(w/2006,h/1716),base*view.z);
    return {w,h,scale,vw:w/scale,vh:h/scale,base};
  }
  function render(){
    const {vw,vh,scale}=metrics();
    const display=scale*window.devicePixelRatio>2?'inline':'none';
    if(detailPlate.getAttribute('display')!==display)detailPlate.setAttribute('display',display);
    view.x=vw>=2006?1003:bound(view.x,vw/2,2006-vw/2);
    view.y=vh>=1716?858:bound(view.y,vh/2,1716-vh/2);
    map.setAttribute('viewBox',[view.x-vw/2,view.y-vh/2,vw,vh].join(' '));
    document.querySelector('#scale').textContent=Math.round(view.z*100)+'%';
    const lon=view.x/34-13,lat=69-view.y/52;
    document.querySelector('#coordinates').textContent=lat.toFixed(1)+'° N   '+Math.abs(lon).toFixed(1)+'° '+(lon<0?'W':'E');
    for(const {text,size} of landLabels){
      text.style.display=view.z>=1.05 && size*scale>=9?'':'none';
    }
    if(scale!==lastScale){
      const width=bound(10/scale,3.2,16);
      for(const {hatch,angle} of Object.values(ownerStyle)){
        document.getElementById(hatch).setAttribute('patternTransform','rotate('+angle+') scale('+bound(1/scale,.25,1.4)+')');
      }
      control.style.setProperty('--outer',width+'px');
      control.style.setProperty('--inner',width*.48+'px');
      for(const {mark,x,y,room,ruleRoom} of zones.values()){
        const size=Math.min(1/scale,room);
        mark.setAttribute('transform','translate('+x+' '+y+') scale('+size+')');
        mark.firstChild.style.display=size>ruleRoom?'none':'';
        mark.style.display=size*scale<.65?'none':'';
      }
      lastScale=scale;
    }
    if(!game)return;
    for(const [id,{band,region}] of Object.entries(bands)){
      const owner=game.owners[id];
      if(band.dataset.owner===owner)continue;
      band.dataset.owner=owner;
      band.style.color=ownerStyle[owner].ink;
      band.lastChild.setAttribute('stroke','url(#'+ownerStyle[owner].hatch+')');
      region.firstChild.textContent=places[id].name+' · '+owner+' control';
    }
    const info=inspectedSea?'Sea zone '+inspectedSea+' · Adjacent '+zones.get(inspectedSea).neighbors.join(', '):
      inspectedPlace?places[inspectedPlace].name+' · '+game.owners[inspectedPlace]+' control':'';
    if(intel.textContent!==info)intel.textContent=info;
    routes.replaceChildren();forces.replaceChildren();
    for(const region of regions.children){
      const id=region.dataset.place;
      const legal=game.phase==='plan'&&places[focus]?.targets.includes(id);
      region.setAttribute('fill',id===target?'#ba84353a':legal?'#d6b65728':'transparent');
      region.setAttribute('stroke',legal?'#895a31':'none');
      region.setAttribute('stroke-width','2');
    }
    const compact=view.z<.66;
    // Taper counter size at the widest tactical scales; keep the interior seats stable
    // while panning, and tighten their spacing at close zoom.
    const tokenScale=Math.min(1/scale,1.2);
    const spread=bound(1/(1.2*scale),.66,1);
    for(const order of game.orders){
      for(const type of types.filter(type=>order.units[type]>0)){
        routes.append(node('path',{d:movementArc(order.from,order.to,type,spread,tokenScale,offsets),
          'data-from':order.from,'data-to':order.to,'data-unit':type,
          stroke:'#99432e','stroke-width':2.55/scale,'stroke-linecap':'round',
          'stroke-dasharray':game.phase==='plan'?(6/scale)+' '+(4/scale):'none','marker-end':'url(#arrow)',fill:'none'}));
      }
    }
    const activeFronts=new Set();
    let selectedAt=null;
    for(const id of Object.keys(places)){
      const [x,y]=position(id),nation=game.owners[id],friendly=nation==='Germany';
      const units=game.phase==='plan'&&friendly?available(game,id):game.units[id];
      const groups=arrivals(game,id).filter(group=>types.some(type=>group.units[type]>0));
      for(const group of groups){
        const key=group.from+'-'+id;
        activeFronts.add(key);
        if(!frontMarks.has(key)){
          const mark=drawFront(group.from,id);
          fronts.append(mark);frontMarks.set(key,mark);
        }
        const ink=frontMarks.get(key).firstChild;
        const transform=frontTransform(id,group,spread,tokenScale);
        if(ink.getAttribute('transform')!==transform)ink.setAttribute('transform',transform);
      }
      if(compact){
        forces.append(node('circle',{cx:x,cy:y,r:7/scale,fill:friendly?'#434f3b':'#3f5964',stroke:'#f7f2df','stroke-width':1.6/scale,'data-place':id}));
        continue;
      }
      const detailed=view.z>=1.55;
      for(const type of types){
        if(!units[type])continue;
        const at=seat(id,'home',type,spread,offsets),selected=id===focus&&type===selectedType;
        drawStack(forces,id,type,units[type],nation,'home',at,tokenScale,detailed,selected);
        if(selected)selectedAt=at;
      }
      for(const group of groups){
        for(const type of types){
          if(group.units[type])drawStack(forces,id,type,group.units[type],'Germany','incoming',
            seat(id,group.from,type,spread,offsets),tokenScale,detailed,false,group.from);
        }
      }
    }
    for(const [key,mark] of frontMarks){
      if(!activeFronts.has(key)){mark.remove();frontMarks.delete(key);}
    }
    // The overlay survives frequent force-layer redraws, so pan or quantity changes
    // reposition the mark without restarting the pencil.
    showSelection(selectedAt?focus+'-'+selectedType:'',selectedAt,tokenScale);
  }
  function zoom(factor,px=map.clientWidth/2,py=map.clientHeight/2) {
    const old=metrics();const wx=view.x+(px-old.w/2)/old.scale,wy=view.y+(py-old.h/2)/old.scale;
    view.z=bound(view.z*factor,.15,4.5);const next=metrics();
    view.x=wx-(px-next.w/2)/next.scale;view.y=wy-(py-next.h/2)/next.scale;render();
  }
  const coords=e=>{const b=map.getBoundingClientRect();return {x:e.clientX-b.left,y:e.clientY-b.top};};
  function basis(){
    const pts=[...pointers.values()]; const a=pts[0],b=pts[1]||a;
    return {x:(a.x+b.x)/2,y:(a.y+b.y)/2,d:Math.hypot(a.x-b.x,a.y-b.y),n:pts.length};
  }
  map.addEventListener('pointerdown',e=>{
    if(e.button!==0)return;
    pointers.set(e.pointerId,coords(e));map.setPointerCapture(e.pointerId);
    let hit=e.target.closest('[data-place],[data-sea]')?.dataset;
    // At wider zoom the printed faces shrink. Give taps in the surrounding territory
    // a 44 px target, resolving shared space to the nearest counter of that territory.
    if(hit?.place&&!hit.unit){
      let nearest=Infinity;
      for(const stack of forces.querySelectorAll('g[data-unit]')){
        if(stack.dataset.place!==hit.place)continue;
        const {e:x,f:y}=stack.getScreenCTM(),dx=e.clientX-x,dy=e.clientY-y;
        const distance=dx*dx+dy*dy;
        if(Math.abs(dx)<=22&&Math.abs(dy)<=22&&distance<nearest){
          hit=stack.dataset;nearest=distance;
        }
      }
    }
    const v=basis();gesture={...v,firstX:v.x,firstY:v.y,moved:v.n>1,id:hit?.place,type:hit?.unit,sea:hit?.sea};
  });
  map.addEventListener('pointermove',e=>{
    if(!pointers.has(e.pointerId)||!gesture)return;
    pointers.set(e.pointerId,coords(e));const v=basis();
    if(Math.hypot(v.x-gesture.firstX,v.y-gesture.firstY)>5)gesture.moved=true;
    if(gesture.moved){
      if(v.n>1&&gesture.d>0&&v.d>0)zoom(v.d/gesture.d,gesture.x,gesture.y);
      const m=metrics();view.x-=(v.x-gesture.x)/m.scale;view.y-=(v.y-gesture.y)/m.scale;
      render();
    }
    Object.assign(gesture,v);
  });
  function end(e){
    if(!pointers.has(e.pointerId))return;
    const tapped=e.type==='pointerup'&&gesture&&!gesture.moved;
    const id=gesture?.id, sea=gesture?.sea;
    const type=gesture?.type;
    pointers.delete(e.pointerId);
    gesture=pointers.size?{...basis(),moved:true}:null;
    if(tapped){
      inspectedPlace=id||null;
      inspectSea(sea && sea!==inspectedSea ? sea : null);
      if(id){
        if(view.z<.66){[view.x,view.y]=position(id);view.z=1.25;}
        onPick(id,type);
      }
      render();
    }
    onView({...view});
  }
  map.addEventListener('pointerup',end);map.addEventListener('pointercancel',end);
  map.addEventListener('wheel',e=>{e.preventDefault();const p=coords(e);zoom(Math.exp(-bound(e.deltaY,-240,240)*.002),p.x,p.y);onView({...view});},{passive:false});
  function button(id,fn){document.getElementById(id).onclick=()=>{fn();render();onView({...view});};}
  button('zoomIn',()=>zoom(1.38));button('zoomOut',()=>zoom(1/1.38));
  button('recenter',()=>{view={x:590,y:985,z:1};});
  button('overview',()=>{const m=metrics();view={x:1003,y:858,z:Math.min(m.w/2006,m.h/1716)/m.base};});
  new ResizeObserver(render).observe(map);
  return (s,id,to,type,seed)=>{
    if(seed!==layoutSeed){offsets=homeOffsets(seed);layoutSeed=seed;}
    game=s;focus=id;target=to;selectedType=type;render();
  };
}
